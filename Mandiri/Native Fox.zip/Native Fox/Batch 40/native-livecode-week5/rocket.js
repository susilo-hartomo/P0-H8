/**
 * Buatlah sebuah function yang akan mengambil input berupa array multidimensi berisi kumpulan angka.
 * Function akan mencari nilai mean, modus, max dari masing-masing array di dalam array multidimensi tersebut.
 * Masing-masing mean, modus, dan max dari array-array tersebut akan disimpan di dalam 1 array.
 *
 * Jika terdapat 2 modus di dalam 1 array, maka modus di array tersebut adalah modus yang terkecil!!!
 *
 * contoh input: [[1,2,3,4], [5,6,5,7]]
 * contoh output:[[mean, modus, max], [mean,modus,max]]
 *               [ [ 2.5, 1, 4 ], [ 5.75, 5, 7 ] ]
 *
 * Rules:
 * -Dilarang menggunakan built-in function selain .push()
 *
 */

function findSpecials(array) {
  var display = [];
    // SORT AGAR LEBIH KECIL DULUAN
    for (i = 0; i < array.length; i++) {
        for (j = 0; j < array[i].length; j++) {
          for (k = 0;k < array[i].length-1; k++) {
              if (array[i][k] > array[i][k+1]) {
                  var tmp = array[i][k];
                  array[i][k] = array[i][k+1];
                  array[i][k+1] = tmp
              }
          }
        }
    }
    // LOOP DATA
  for (i = 0; i < array.length; i++) {
    var tmp = [];
    var nilai = 0;
    var modus = 0;
    var check = 0;
    var max = 0;
    for (j = 0; j < array[i].length; j++) {
      var counter = 0;
      nilai += array[i][j];
      if (max < array[i][j]) {
        max = array[i][j];
      }
      for (k = 0; k < array[i].length; k++) {
        if (array[i][j] === array[i][k]) {
          counter++;
        }
      }
      if (check < counter) {
        modus = array[i][j];
        check = counter;
      }
    }
    var rata = nilai / array[i].length;
    tmp.push(rata, modus, max);
    display.push(tmp);
  }
  return display;
}

//test-cases
console.log(
  findSpecials([
    [2, 2, 2, 4, 5, 6, 8, 9],
    [2, 2, 2, 0, 9],
    [3, 4, 5, 8, 8, 8, 3, 3, 2, 10]
  ])
);
//[ [ 4.75, 2, 9 ], [ 3, 2, 9 ], [ 5.4, 3, 10 ] ]

console.log(
  findSpecials([
    [1, 2, 3, 4],
    [5, 6, 5, 7]
  ])
);
//[ [ 2.5, 1, 4 ], [ 5.75, 5, 7 ] ]
