/**
 * 
 * Diberikan sebuah arrray, array tersebut bisa memiliki panjang genap atau ganjil. 
 * Jika panjang array ganjil, maka hilangkan elemen yang berada di tengah2 array tersebut.
 * Jika panjang array genap, maka hilangkan elemen kedua dari kiri dan elemen kedua dari kanan.
 * Lihatlah test-case untuk lebih jelasnya.
 * 
 *
 * 
 * Rules:
 * -Dilarang menggunakan built-in function selain .push(), parseInt(), dan Math.round()
 * -TIDAK MENULISKAN PSEUDOCODE = 0!
 * 
 */

//tulislah pseudocode disini!
/*
============
PSEUDOCODE
============
SET DISPLAY with empty array
SET INDEX with empty array
IF ARRAY.LENGTH mod 2 equal with 1
  PUSH INDEX with CAL array.length devide by 2
  END IF
ELSE IF ARRAY.LENGTH mod 2 equal with 0
  PUSH INDEX with 1 and CAL array.length minus 2
  END IF
FOR EACH ARRAY
  SET CHECK with false value
  FOR EACH INDEX
    IF i equal with index
      CHECK equal to true
    END IF
  END FOR
  IF CHECK equal to false
    PUSH DISPLAY with array[i]
  END IF
END FOR
DISPLAY DISPLAY
*/

function makeEven(array) {
  var display = []
  var index = []
  // CARI INDEX
  if(array.length % 2 === 1){
    index.push(Math.floor(array.length/2))
  } else if (array.length % 2 === 0){
    index.push(1,array.length-2)
  }
  // PUSH DISPLAY
  for (i = 0; i < array.length; i++) {
    var check = false
    for (j = 0; j < index.length; j++) {
      if(i === index[j]){
        check = true
      }
    }
    if(!check){
      display.push(array[i])
    }
  }
  return display
}

console.log(makeEven([1,2,3,4,5])); //[ 1, 2, 4, 5 ]
console.log(makeEven([2,3,4,5,6,7,8])); //[2, 3, 4, 6, 7, 8]
console.log(makeEven([1,2,3,4,5,6])); //[1, 3, 4, 6]
console.log(makeEven([1,2])); //[]
console.log(makeEven([1,2,3,4])) //[1,4]