/**
 * 
 * Kalian diminta untuk mengoptimalkan sebuah fitur menu restaurant, karena saat ini, order minuman dan makanan harus dibuat terpisah.
 * Bantulah restoran untuk membuat program yang akan menggabungkan kedua pesanan tersebut.
 * 
 * Function menuOptimizer akan menerima 2 array, satu array berisi order makanan dan array kedua berisi order minuman. Di dalam 
 * tiap array akan ada order dengan format:
 * 
 * 'nama-makanan' atau 'nama-minuman'
 * 
 * Kalian diminta untuk mengelompokkan kedua pesanan ini dalam satu array 2 dimensi dengan format:
 * [['nama orang1', 'nama makanan orang1', 'nama minuman orang1'], ['nama orang2', 'nama makanan orang2', 'nama minuman orang2'], dst]
 * 
 * Contoh input: ['audrick-egg', 'ricky-chicken'], ['ricky-milk', 'audrick-coffee']
 * 
 * Maka Outputnya adalah:
 * [['audrick', 'egg', 'coffee'], ['ricky','chicken','milk']]
 * 
 * Semua orang pasti memesan makanan dan minuman, sehingga tidak ada kasus dimana ada yang tidak memesan makanan atau minuman
 * 
 * Rules:
 * - Dilarang menggunakan built-in function selain .push()!
 * 
 * 
 */

function menuOptimizer(arr1,arr2) {
  var display = []
  var obj = {}
  var array = []
  // ARRAY 1
  for (i = 0; i < arr1.length; i++) {
    var tmp = []
    var temp = ''
    for (j = 0; j < arr1[i].length; j++) {
      if(arr1[i][j] === '-'){
        tmp.push(temp)
        temp = ''
      } else {
        temp += arr1[i][j]
      }
    }
    tmp.push(temp)
    array.push(tmp)
  }
  // ARRAY 2
  for (i = 0; i < arr2.length; i++) {
    var tmp = []
    var temp = ''
    for (j = 0; j < arr2[i].length; j++) {
      if(arr2[i][j] === '-'){
        tmp.push(temp)
        temp = ''
      } else {
        temp += arr2[i][j]
      }
    }
    tmp.push(temp)
    array.push(tmp)
  }
  // OBJ
  for (i = 0; i < array.length; i++) {
    if(obj[array[i][0]] === undefined){
      obj[array[i][0]] = [array[i][1]]
    } else {
      obj[array[i][0]].push(array[i][1])
    }
  }
  // DISPLAY
  for(let key in obj){
    var tampung = []
    tampung.push(key)
    for (i = 0; i < obj[key].length; i++) {
      tampung.push(obj[key][i])
    }
    display.push(tampung)
  }
  return display
}


console.log(menuOptimizer(
  ['audrick-chicken', 'ayu-cereal', 'ari-bread', 'arnold-soup', 'adiel-chicken'],
  ['adiel-coffee','audrick-soda', 'ayu-milk', 'arnold-juice', 'ari-soda'])
)
/**
 * [
  [ 'audrick', 'chicken', 'soda' ],
  [ 'ayu', 'cereal', 'milk' ],
  [ 'ari', 'bread', 'soda' ],
  [ 'arnold', 'soup', 'juice' ],
  [ 'adiel', 'chicken', 'coffee' ]
]
 */
console.log(menuOptimizer(
  ['audrick-egg', 'ricky-chicken'], 
  ['ricky-milk', 'audrick-coffee'])
  ) 
//[ [ 'audrick', 'egg', 'coffee' ], [ 'ricky', 'chicken', 'milk' ] ]