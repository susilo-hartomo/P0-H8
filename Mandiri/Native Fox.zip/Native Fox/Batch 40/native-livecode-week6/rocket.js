/**
 * Function putDiagonal menerima input berupa sebuah string. String ini harus ditaruh ke dalam diagonal kanan sebuah array 2 dimensi.
 * Untuk lokasi lain di dalam array tersebut, taruh lah string '*'.
 * Panjang row dan column dari array tersebut sepanjang string input. 
 * Lihatlah test-case untuk lebih jelasnya.
 *
 * Rules:
 * -Dilarang menggunakan built-in function selain .push()!
 * 
 */
function putDiagonal(str) {
  var display = []
  // FIND INDEX
  var index = str.length-1
  // DISPLAY
   for (i = 0; i < str.length; i++) {
     var tmp = []
     for (j = 0; j < str.length; j++) {
      if(j === index){
        tmp.push(str[i])
      } else {
        tmp.push('*')
      }
     }
     display.push(tmp)
     index--
   }
   return display
}


console.log(putDiagonal('dgjm'));
/**
 * 
 [
  [ '*', '*', '*', 'd' ],
  [ '*', '*', 'g', '*' ],
  [ '*', 'j', '*', '*' ],
  [ 'm', '*', '*', '*' ]
]
 * 
 */

 console.log(putDiagonal('abcdef'))
//  [
//     [ '*', '*', '*', '*', '*', 'a' ],
//     [ '*', '*', '*', '*', 'b', '*' ],
//     [ '*', '*', '*', 'c', '*', '*' ],
//     [ '*', '*', 'd', '*', '*', '*' ],
//     [ '*', 'e', '*', '*', '*', '*' ],
//     [ 'f', '*', '*', '*', '*', '*' ]
// ]