/*
=====================
Word Spread Reduction
=====================

[INSTRUCTION]
buatlah program yang dapat melakukan penyebaran (spread) dimulai dari 1 char dalam suatu kata, lalu dapat menyusut lagi
menjadi 1 char, hingga membentuk seperti segitiga.

[EXAMPLE]
var name = "Dimas"

output: 
D
Di
Dim
Dima
Dimas
Dima
Dim
Di
D
*/

var name = "Dimas"
// your code here
