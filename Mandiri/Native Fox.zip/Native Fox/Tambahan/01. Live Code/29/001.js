/*
========
Car Line
========

Buatlah Pseudocode untuk kasus berikut:

Sebuah mobil sedang melaju dengan kecepatan 60km/jam
Mobil tersebut dipengaruhi oleh jalur lintasan yang dilewati.

- Jika lintasan lurus, maka kecepatan tetap.
- Jika lintasan belok kanan/ kiri, maka kecepatan akan berkurang sebesar 20% dari kesepatan sekarang
- Jika lintasan menanjak, maka kecepatan akan berkurang sebesar 50%
- Jika lintasan menurun, maka kecepatan akan bertambah sebesar 30%

Tampilkan kecepatan mobil jika di depan adalah lintasan 'x'

*/

// Write Psedocode here
