/*
    analisa sendiri dengan apa yang diminta soal melalui test case. 
    wajib menggunakan pseudocode

    PSEUDOCODE HERE : 

*/

function soal1(param) {
    // Write your code here

}

console.log(soal1(3))
// output : ['!','@','#']

console.log(soal1(6));
// output : ['!','@','#','!','@','#']

console.log(soal1(4))
// output : ['!','@','#','!']

console.log(soal1(0)) // invalid input

/*

0 3 6 -> ! var tandaSeru = 0 += 3
1 4 7 -> @
2 5 8 -> #

*/