function soal1(param) {
    // Write your code here
    
}

console.log(soal1("Aries Dimas Yudhistira"));
/*

    a
    r
    i
    t
    s
    i
    h
    d
    u
    Y

    s
    a
    m
    i
    D

    s
    e
    i
    r
    A

*/