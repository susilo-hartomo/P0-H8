function persegi(param1,param2) {
    // Write your code here
    
}

console.log(persegi(5,7))

/*
    #####
    #   #
    #   #
    #   #
    #   #
    #   #
    #####
*/

console.log(persegi(6,3))

/*
    ######
    #    #
    ######
*/

console.log(persegi(0,7)) // invalid value 
console.log(persegi(4,0)) // invalid value 