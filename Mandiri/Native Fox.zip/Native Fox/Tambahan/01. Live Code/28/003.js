// Hanya boleh menggunakan rekursif

function soal3(param1, param2) {
    // Write your code here

}

console.log(soal3(2,5))
/*
    2 * 2 * 2 * 2 * 2 
    32
*/

console.log(soal3(3,3))
/*
    3*3*3 = 27
*/