/*
  ///////////////////
  richestGroupDynamic
  ///////////////////
  Function richestGroupDynamic akan menentukkan siapa yang paling kaya dalam suatu grup.
  Function akan menerima 1 parameter yaitu:
    - groups adalah array yang berisi kumpulan data vote, tipe datanya array.
  Function ini akan mengembalikkan nilai string.

  ----------
  EXAMPLE 1:
  ----------
  [INPUT]
    var groups = [
      ['A', 'B', 'C'],
      ['A', 'A', 'D', 'D', 'D']
    ]
  [PROCESS]
  Pada array ['A', 'B', 'C'] tidak ada yang unggul.
  Pada array ['A', 'A', 'D', 'D', 'D'] D unggul.
  [OUTPUT]
    [ 'D' ]
  ----------
  EXAMPLE 2:
  ----------
  [INPUT]
    var groups = [
      ['Z', 'Z'],
      ['B']
    ]
  [PROCESS]
  Pada array ['Z', 'Z'] Z unggul.
  Pada array ['B'] B unggul.
  [OUTPUT]
    [ 'Z', 'B' ]
  [RULES]
    1. Dilarang menggunakan built in function apapun kecuali .push(), .unshift().
*/

function richestGroupDynamic (groups) {
  var display = []
  for (i = 0; i < groups.length; i++) {
    if(groups[i].length === 1){
      display.push(groups[i][0])
    }
    var tmp = []
    for (j = 0; j < groups[i].length; j++) {
      var check = false
      for (k = 0; k < tmp.length; k++) {
        if(groups[i][j] === tmp[k][1]){
          var check = true
          tmp[k][0]++
        }
      }
      if(check === false){
        tmp.push([1,groups[i][j]])
      } 
    }
    sorting(tmp);
    if(tmp[0][0] !== 1){
      display.push(tmp[0][1])
    }
  }
  return display
}

function sorting (arr) {
  var sort = arr
  for (let i = 0; i < sort.length; i++) {
    for (let j = 0; j < sort.length-1-i; j++) {
      if (sort[j][0] < sort[j+1][0]) {
        var temp = sort[j]
        sort[j] = sort[j+1]
        sort[j+1] = temp
      }
    }
  }
  return sort
}

console.log(richestGroupDynamic([
  ['A', 'B', 'C'],
  ['A', 'A', 'D', 'D', 'D']
]))
// [ 'D' ]

console.log(richestGroupDynamic([
  ['A', 'A'],
  ['B']
]))
// [ 'A', 'B' ]

console.log(richestGroupDynamic([
  ['Z', 'Z'],
  ['B', 'X']
]))
// [ 'Z' ]

console.log(richestGroupDynamic([['A','B','A','B','A'],['Z','X','Y','Q','Q','X','Y','Y']]))
// ['A','Y']
// ['Z','X','Y','Q','Q','X','Y','Y']
