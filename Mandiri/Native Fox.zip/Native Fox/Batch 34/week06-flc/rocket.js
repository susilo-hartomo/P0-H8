/*
  /////
  order
  /////
  Function order ini hanya berfungsi mengurutkan number dari kecil ke besar dalam bentuk string
  dan outputnya disatukan dengan satu spasi. Apabila ada angka yang sama selalu urutkan dari paling
  kiri.

  [RULES]
  1. Tidak boleh menggunakan built in function selain .push() dan .unshift()
*/

function order (words) {
  // SPLIT
  var split = []
  var tmp = ''
  for (i = 0; i < words.length; i++) {
    if(words[i] === ' ' && words[i-1] !== ' '){
      split.push(tmp)
      tmp = ''
    } else if(words[i] === ' '){
        var kosong;
    } else {
      tmp += words[i]
    }
  }
  split.push(tmp)
  // CARI INDEX
  var index = []
  for (i = 0; i < split.length; i++) {
    var temp = 0
    for (j = 0; j < split[i].length; j++) {
      if(Number(split[i][j]) > 0){
        temp += split[i][j]
      }
    }
    index.push([temp,i])
  }
  // SORT NUMBER
  for (i = 0; i < index.length; i++) {
    for (j = 0;j < index.length-1; j++) {
      if (index[j][0] > index[j+1][0]) {
        var tmp = index[j];
        index[j] = index[j+1];
        index[j+1] = tmp
      }
    }
  }
  // OUTPUT
  var display = ''
  for (i = 0; i < index.length; i++) {
   display += split[index[i][1]] + ' '
  }
  return display
}

console.log(order('is2 Thi1s T4est 3a')) // "Thi1s is2 3a T4est
console.log(order('4of Fo-10r       pe6000ople   g3ood    th5e  the2')) // "Fo-10r the2 g3ood 4of th5e pe6000ople"
console.log(order('i1s Thi0s m2e real1')) // "Thi0s i1s real1 2me"
console.log(order('')) // ""
