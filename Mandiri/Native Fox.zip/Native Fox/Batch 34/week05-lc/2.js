/*
========
warOfFun
========
[INSTRUCTIONS]
warOfFun adalah sebuat fungsi yang menerima parameter berupa string dan
akan mengembalikan nilai string yang merupakan pemenang perlombaan.
[EXAMPLE]
INPUT: [
  ['andre', 'toni', 'toti'],
  ['risk', 'fun', 'go'],
  ['humble', 'psycho', 'strong']
]
PROCESS:
1. array[0] akan berisi nama-nama pemain
2. array-aray pada indeks berikutnya akan berisi attribut-attribut yang dimiliki oleh setiap pemain sesuai dengan indeksnya
3. pada array[1] andre tidak memiliki fun, toni memiliki 1 fun, dan toti tidak memiliki fun
4. pada array[2] andre tidak memiliki fun, toni tidak memiliki fun, dan toti tidak memiliki fun.
5. total andre tidak memiliki fun, toni memiliki 1 fun, dan toti tidak memiliki fun, sehingga pemenangnya adalah toni.
OUTPUT: pemenangnya adalah toni
[NOTES]
  1. Apabila tidak ada pemenang tampilkan "mohon maaf tidak ada pemenangnya"
  2. Asumsi tidak akan ada yang seri tapi tidak selalu ada pemenangnya
[RULES]
  1. Dilarang menggunakan built in function .sort()
*/

function warOfFun (informations) {
//...
  var player = informations[0]
  var fun = []
  informations.shift()
  // CARI FUN
  for (i = 0; i < informations.length; i++) {
    for (j = 0; j < informations.length; j++) {
      if(informations[i][j] === 'fun'){
        fun.push(player[j])
      }
    }
  }
  // CARI TERBANYAK
  var display = []
  for (i = 0; i < fun.length; i++) {
    var index = -1
    for (j = 0; j < display.length; j++) {
      if(fun[i] === display[j][0]){
        index =  j
      }
    }
    if(index === -1){
      display.push([fun[i],1])
    } else {
      display[index][1]++
    }
  }
  // SORT
  for (i = 0; i < display.length; i++) {
    for (j = 0;j < display.length-1; j++) {
      if (display[j][1] < display[j+1][1]) {
        var tmp = display[j];
        display[j] = display[j+1];
        display[j+1] = tmp
      }
    }
  }
  // RESULT
  if(display == false){
    return `Mohon maaf tidak ada pemenangnya`
  } else {
    return `Pemenangnya adalah ${display[0][0]}`
  }
}

console.log(warOfFun([
  ['andre', 'toni', 'toti'],
  ['risk', 'fun', 'go'],
  ['humble', 'psyhco', 'strong']
]))
// pemenangnya adalah toni

console.log(warOfFun([
  ['andre', 'toni', 'toti', 'tito'],
  ['fun', 'fun', 'fun'],
  ['fun', 'fun'],
  ['nonfun', 'fun', 'fun', 'fun']
]))
// pemenangnya adalah toni

console.log(warOfFun([
  ['andre', 'toni'],
  ['risk', 'go'],
  ['humble', 'strong']
]))
// mohon maaf tidak ada pemenangnya

console.log(warOfFun([]))
// mohon maaf tidak ada pemenangnya
