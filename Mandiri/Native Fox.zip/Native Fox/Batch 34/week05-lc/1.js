/*
===========
eMoneySplit
===========
[INSTRUCTIONS]
eMoneySplit adalah sebuah fungsi yang menerima parameter berupa string
dan akan mengembalikan nilai string yang merupakan jumlah terbanyak dan terdikit.
[EXAMPLE]
INPUT: "bagus:200000,ali:20000,bagas:300000,andre:50000"
OUTPUT: terbanyak adalah bagas dan terdikit adalah ali
[NOTES]
1. Apabila tidak ada data tampilkan "tidak ada catatan eMoney"
[RULES]
1. WAJIB menggunakan algoritma/pseudocode atau -50 poin
*/

/*
================================================================
PSEUDOCODE:
-----------
SET ARR with empty array
SET TEMP with empty array
SET TMP with empty string
FOR each str
  ADD TMP with str[i]
  IF str[i] equal with ':'
    PUSH TMP to TEMP
    SET TMP with empty string
  ELSE IF str[i] equal with ','
    PUSH TMP to TEMP
    PUSH TEMP to ARR
    SET TEMP to empty array
    SET TMP to tempty string
  END IF
END FOR
PUSH TMP to TEMP
PUSH TEMP to ARR
SORT ARR
DISPLAY first ARR AND DISPLAY end of ARR
================================================================
*/

function eMoneySplit (str) {
    var arr = []
    var temp = []
    var tmp = ''
    // SPLIT
    for (i = 0; i < str.length; i++) {
      if(str[i] === ':'){
        temp.push(tmp)
        tmp = ''
      } else if(str[i] === ','){
        temp.push(Number(tmp))
        arr.push(temp)
        temp = []
        tmp = ''
      } else {
        tmp += str[i]
      }
    }
    temp.push(Number(tmp))
    arr.push(temp)
    // SORT
    for (i = 0; i < arr.length; i++) {
      for (j = 0;j < arr.length-1; j++) {
        if (Number(arr[j]) < Number(arr[j+1])) {
          var tmp = arr[j];
          arr[j] = arr[j+1];
          arr[j+1] = tmp
        }
      }
    }
    // DISPLAY
    if(!str){
      return `tidak ada catatan eMoney`
    } else {
      return `terbanyak adalah ${arr[0][0]} dan terdikit adalah ${arr[arr.length-1][0]}`
    }
}
  
  console.log(eMoneySplit('bagus:200000,ali:20000,bagas:300000,andre:50000'))
  // terbanyak adalah bagas dan terdikit adalah ali
  console.log(eMoneySplit('andre:50000'))
  // terbanyak adalah andre dan terdikit adalah andre
  console.log(eMoneySplit(''))
  // tidak ada catatan eMoney
  