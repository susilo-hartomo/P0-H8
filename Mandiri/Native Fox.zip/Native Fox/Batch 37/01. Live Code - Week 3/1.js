/*
==============
Bola ping-pong
==============

Di dalam sebuah kotak A ada 50 bola ping-pong.
Setiap bola ping pong bisa berwarna merah atau putih.

Buatlah pseudocode untuk menghitung jumlah
bola ping-pong berwarna merah dan putih masing-masing di dalam kotak A.

===== jawaban =====

*/
