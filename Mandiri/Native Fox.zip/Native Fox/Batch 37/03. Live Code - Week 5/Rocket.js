/**
 * ================
 * Balanced Letters
 * ================
 * 
 * [Description]
 * isBalanced merupakan sebuah function yang mengecek apakah jumlah huruf yang diterima sebagai input berjumlah sama.
 * 
 * [Example]
 * @input = abcde
 * karena masing-masing karakter (a-e) hanya muncul sekali, maka:
 * @output = true
 * 
 * @input = abcdeabcde
 * karena masing-masing karakter (a-e) muncul dua kali, maka:
 * @output = true
 * 
 * @input = abcba
 * huruf a & b muncul 2x, namun huruf c hanya muncul sekali, maka:
 * @output = false
 * 
 * [Rules]
 * 1. Dilarang menggunakan regex
 * 2. Dilarang menggunakan built-in function: map, filter, reduce, forEach
 * 3. Dilarang menggunakan built-in function: sort
 * 4. Dilarang menggunakan built-in function: split, slice, splice, join, reverse
 * 5. Dilarang menggunakan built-in function: indexOf, lastIndexOf, includes, some, every, find
*/

function isBalanced(str) {
    var tmp = []
    for (i = 0; i < str.length; i++) {
        var same = false
        for (j = 0; j < tmp.length; j++) {
            if(str[i] === tmp[j][0]){
                tmp[j][1]++
                same = true
            }
        }
        if(same == false){
            tmp.push([str[i],1])
        } 
    }
    return tmp
    // LOOP OUTPUT
    for (i = 0; i < tmp.length-1; i++) {
        if(tmp[i][1] !== tmp[i+1][1]){
            return false;
        } 
    }
    return true;
}

console.log(isBalanced('abcdefghijkl'))
// true
console.log(isBalanced('aabbccddeeff'))
// true
console.log(isBalanced('abcdedcba'))
// false
console.log(isBalanced('hfsjdfngkso'))
// false
console.log(isBalanced('pqqwlearmssipqqwlezoxpjaozvxgcfpqqwlearvjasybinoxpdwfbgchhzvxgcfvybrntmzyjdmtkutzykuoinarmtxpjlpqqwlassidwfbgchhjdkuearsimtzdwfbgchhjdkulezvxpqqwlearmssipqqwlezoxpjaozvxgcfpqqwlearvjasybinoxpdwfbgchhzvxgcfvybrntmzyjdmtkutzykuoinarmtxpjlpqqwlassidwfbgchhjdkuearsimtzdwfbgchhjdkulezvxgcfvybrntykuoinoxpjassidwfbgchhjdkulekuoinoyerntmkulezvxgcfvybrntmmgcfvybrntykuoinoxpjassidwfbgchhjdkulekuoinoyerntmkulezvxgcfvybrntmm'))
// true