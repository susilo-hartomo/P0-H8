/**
 * ============
 * Hitung Prima
 * ============
 *
 * [Instruction]
 * Buatlah sebuah function untuk menghitung ada berapa angka prima dari angka 0 sampai @num
 * dimana @num adalah angka input yang diberikan sebagai parameter untuk function hitungPrima kita
 *
 * [Rules]
 * 1. `Wajib menggunakan rekursif`
 * 2. Dilarang menambah dan merubah tipe data parameter
 * 3. Dilarang membuat function lain selain hitungPrima
 * 4. Hanya diperbolehkan `menggunakan 1 loop`
 */

function hitungPrima(num) {
  var display = []
  for (i = 2; i <= num; i++) {
    var check = true
    for (j = 2; j < i; j++) {
      if(i % j === 0){
        check = false
      }
    }
    if(check == true){
      display.push(i)
    }
  }
  if(display == false){
    return 0
  } else {
    return `${display.length} (karena ${display} adalah prima)`
  }
}

console.log(hitungPrima(1)); // 0
console.log(hitungPrima(2)); // 1 (karena 2 adalah prima)
console.log(hitungPrima(10)); // 4 (karena 2,3,5,7 adalah prima)
console.log(hitungPrima(20)); // 8 (karena 2,3,5,7,11,13,17,19 adalah prima)
