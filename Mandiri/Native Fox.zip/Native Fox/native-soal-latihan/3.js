/*
* Convert time to words
* Function timeToWords menerima input berupa string yang merupakan sebuah waktu. 
* Function ini berfungsi merubah waktu menjadi sebuah kalimat.
* Waktu yang ditampilkan adalah waktu 24 jam.
*
* EXAMPLE 1 ------------------------
* Input: 
* '05:30'
* 
* Output:
* 'Jam setengah 6'
*
* EXAMPLE 2 ------------------------
* Input: 
* '03:10'
* 
* Output:
* 'Jam 3 lebih 10 menit'
*
* EXAMPLE 3 ------------------------
* Input: 
* '07:40'
* 
* Output:
* 'Jam 8 kurang 20 menit'
*
* RULES:
* - TIDAK MENGGUNAKAN MAGIC. ex: split() slice() splice() map() reduce() etc.
*/
function timeToWords(waktu) {
  var split = []
  var tmp = ''
  for (i = 0; i < waktu.length; i++) {
    if(waktu[i] === ':'){
      split.push(tmp)
      tmp = ''
    } else {
      tmp += waktu[i]
    }
  }
  split.push(tmp)
  // DISPLAY
  if(Number(split[1]) === 0){
    return `Jam ${split[0]}`
  } else if(split[1] === '30'){
    return `Jam setengah ${Number(split[0]) + 1}`
  } else if(Number(split[1]) > 30){
    return `Jam ${Number(split[0]) + 1} kurang ${60 - Number(split[1])} Menit`
  } else {
    return `Jam ${split[0]} lebih ${split[1]} Menit`
  }
}
console.log(timeToWords('10:10')); // Jam 10 lebih 10 menit
console.log(timeToWords('01:30')); // Jam setengah 2
console.log(timeToWords('09:47')); // Jam 10 kurang 13 menit
console.log(timeToWords('11:00')); // Jam 11