/**
 * Encrypt Word
 *
 * Function encryptWord menerima input berupa string yang akan menghasilkan sebuah string baru,
 * untuk menghasilkan string barunya kita harus merubah string awalnya menjadi array multidimensi
 * dimana setiap barisnya hanya boleh diisi oleh 4 karakter
 * setelah berhasil membuat array multidimensinya
 * maka proses pembuatan outputnya mengambil karakter dari paling kiri atas lalu kebawah hingga ujung array
 * lalu kembali keatas pada kolom selanjutnya mulai dari baris pertama
 *
 *
 * Input :
 * feedthedog
 *
 * Proses:
 * [
 *   [ 'f', 'e', 'e', 'd' ],
 *   [ 't', 'h', 'e', 'd' ],
 *   [ 'o', 'g' ]
 * ]
 *
 *
 * Output :
 * ftoehgeedd
 *
 *
 * RULES
 * 1. TIDAK MENGGUNAKAN MAGIC. ex: split() slice() splice() map() reduce() etc.
 *
 */
function encryptWord(kata) {
  // MULTIDIMENSI
  var array = [];
  var tmp = [];
  for (i = 0; i < kata.length; i++) {
    if (tmp.length === 4) {
      array.push(tmp);
      tmp = [];
      tmp.push(kata[i]);
    } else {
      tmp.push(kata[i]);
    }
  }
  array.push(tmp);
  // DISPLAY
  var display = ''
  for (i = 0; i < array[0].length; i++) {
    for (j = 0; j < array.length; j++) {
      if(array[j][i] !== undefined)
      display += array[j][i]
    }
  }
  return display
}
console.log(encryptWord("haveaniceday"));
//haeandviaecy
console.log(encryptWord("feedthedog"));
//ftoehgeedd
console.log(encryptWord("sekarangtahunduaribuduapuluh"));
//srtnrdueaadiulknhubauaguauph
