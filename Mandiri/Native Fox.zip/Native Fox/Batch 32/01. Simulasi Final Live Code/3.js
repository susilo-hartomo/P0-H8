/*
=====================
Max Subset Sum
=====================

[INSTRUCTION]
Diberikan sebuah function yang menerima parameter array bilangan bulat. Dimana
function ini berfungsi untuk mengembalikan jumlah maksimum dari dua buah nilai
yang dijumlahkan didalam array tersebut

[EXAMPLE]
- Bila array adalah [-2, 1, 3, -4, 5], maka nilai maksimum adalah 8 karena dua nilai yang
dapat menghasilkan nilai maksimum adalah 3 + 5

[RULE]
1. dilarang menggunakan indexOf(), find(), filter(), shift(), unshift(), sort()
2. dilarang menggunakan regex
3. dilarang menggunakan map, filter, reduce, apply
*/

function maxSubsetSum(arr) {
  var sort = arr
  for (i = 0; i < sort.length; i++) {
    for (j = 0;j < sort.length; j++) {
      if (sort[j] < sort[j+1]) {
        var tmp = sort[j];
        sort[j] = sort[j+1];
        sort[j+1] = tmp
      }
    }
  }
  return sort[0]+sort[1]
}

console.log(maxSubsetSum([-2, 1, 3, -4, 5])); // 8
console.log(maxSubsetSum([-1, 2, 5, 7])); // 12
console.log(
  maxSubsetSum([
    943,
    3893,
    43,
    33,
    394,
    384843,
    3849464,
    5725474,
    27,
    485947,
    474262
  ])
);
// 9574938
