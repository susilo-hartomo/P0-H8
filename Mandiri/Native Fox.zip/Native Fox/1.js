/**
 * CALCULATE TAX
 *  
 * Buathlah sebuah function yang akan membagi mobil berdasarkan pajak, dan menghitung pajak,
 * mobil tersebut.
 * 
 * pajak di tentukan dari harga mobil tersebut , berikut listnya:
 *  1. dibawah 250 jt = 10%
 *  2. dibawah 400 jt = 20%
 *  3. 400 jt ke atas = 30 % 
 *  
 *  Contoh bisa liat di test case
 * 
 *  RULES: 
 *  - Dilarang menggunakan .reduce .filter .map .regex .split .set 
 * 
 * 
 */

function main (cars) {
  var display = {
    '30%': [],
    '20%': [],
    '10%': []
}
  // TAX
  for (i = 0; i < cars.length; i++) {
    tax = 0
    if(cars[i].price > 400000000){
      tax = cars[i].price * 0.3
      display['30%'].push({
        brand: cars[i].brand,
        merk: cars[i].merk,
        type: cars[i].type,
        tax : tax.toString()
      })
    } else if(cars[i].price < 400000000  && cars[i].price >= 250000000){
      tax = cars[i].price * 0.2
      display['20%'].push({
        brand: cars[i].brand,
        merk: cars[i].merk,
        type: cars[i].type,
        tax : tax.toString()
      })
    } else if(cars[i].price < 250000000){
      tax = cars[i].price * 0.1
      display['10%'].push({
        brand: cars[i].brand,
        merk: cars[i].merk,
        type: cars[i].type,
        tax : tax.toString()
      })
    }
  }
  // SPLIT TAX 
  for(let key in display){
    for (i = 0; i < display[key].length; i++) {
      var reverse = ''
      var dot = 0
      for (j = display[key][i].tax.length-1; j >= 0; j--) {
        reverse += display[key][i].tax[j]
        dot ++
        if(dot % 3 === 0 && j !== 0){
          reverse += '.'
        }
      }
      var rp = 'Rp. '
      for (k = reverse.length-1; k >= 0; k--) {
        rp += reverse[k]
        if(k === 0){
          rp += ',00'
        }
      }
      display[key][i].tax = rp
    }
  }
  // DELETE KEY KOSONG
  for(let key in display){
    if(display[key] == false){
      delete display[key]
    }
  }
  return display
}


console.log(main([
  { brand: "BMW", merk: "I8", type: "Coupe", price: 500000000 },
  { brand: "TOYOTA", merk: "Yaris", type: "Coupe", price: 250000000 },
  { brand: "HONDA", merk: "Civic", type: "Sedan", price: 220000000 },
  { brand: "HONDA", merk: "City", type: "Sedan", price: 300000000 },
  { brand: "MITSUBISHI", merk: "Pajero", type: "SUV", price: 600000000},
  { brand: "SUZUKI", merk: "Ertiga", type: "SUV", price: 180000000}
]))
// {
//   '30%': [
//     { brand: 'BMW', merk: 'I8', type: 'Coupe', tax: 'Rp. 150.000.000,00' },
//     { brand: 'MITSUBISHI', merk: 'Pajero', type: 'SUV', tax: 'Rp. 180.000.000,00' }
//   ],
//   '20%': [
//     { brand: 'TOYOTA', merk: 'Yaris', type: 'Coupe', tax: 'Rp. 50.000.000,00' },
//     { brand: 'HONDA', merk: 'City', type: 'Sedan', tax: 'Rp. 60.000.000,00' }
//   ],
//   '10%': [
//     { brand: 'HONDA', merk: 'Civic', type: 'Sedan', tax: 'Rp. 22.000.000,00' },
//     { brand: 'SUZUKI', merk: 'Ertiga', type: 'SUV', tax: 'Rp. 18.000.000,00' }
//   ],
// }

console.log(main([
  { brand: "DAIHATUS", merk: "AYLA", type: "Coupe", price: 130000000 },
  { brand: "TOYOTA", merk: "AGYA", type: "Coupe", price: 150000000 },
  { brand: "HONDA", merk: "JAZZ", type: "Coupe", price: 280000000 },
  { brand: "TOYOTA", merk: "AVANZA", type: "SUV", price: 300000000 },
]))
// {
//   '10%': [
//     { brand: 'DAIHATUS', merk: 'AYLA', type: 'Coupe', tax: 'Rp. 13.000.000,00' },
//     { brand: 'TOYOTA', merk: 'AGYA', type: 'Coupe', tax: 'Rp. 15.000.000,00' }
//   ],
//   '20%': [
//     { brand: 'HONDA', merk: 'JAZZ', type: 'Coupe', tax: 'Rp. 56.000.000,00' },
//     { brand: 'TOYOTA', merk: 'AVANZA', type: 'SUV', tax: 'Rp. 60.000.000,00' }
//   ]
// }