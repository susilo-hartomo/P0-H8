/*
=====
Hacktiv Mining
=====
[INSTRUCTIONS]
salesAmount adalah fungsi yang mengambil parameter:
    1. array penjualan/sales hasil tambang dari berbagai macam tambang yang dimiliki oleh perusahaan Hacktiv
    2. nama mineral yang ingin diketahui jumlah salesnya dari semua tambang-tambang tersebut.
Fungsi ini akan me-return jumlah pendapatan dari penjualan suatu mineral. 
Berikut ini adalah daftar mineral beserta harga-harganya:
    - sulfur dengan harga 10
    - silver dengan harga 30
    - malachite dengan harga 50
    - gold dengan harga 50
    - diamond dengan harga 100
[EXAMPLE]
INPUT : 
- hasil tambang: [['silver','silver','gold'], ['gold','malachite']]
- mineral yang dicari nilai penjualannya: gold
PROSES:
1. Ada 2 tambang, tambang pertama menghasilkan [silver,silver,gold] dan tambang kedua menghasilkan [gold,malachite]
2. Di semua tambang perusahaan Hacktiv, terdapat 2 biji hasil tambang gold.
3. Harga gold adalah 50, jadi hasil penjualan gold adalah 2 ⨉ 50 = 100
OUTPUT:
100
[RULES]
1. WAJIB menggunakan algoritma/pseudocode atau -50 poin
*/

/*
PSEUDOCODE
STORE MINERAL with 0 value
IF DUA equal with sulfur add 10 to mineral value
IF DUA equal with silver add 30 to mineral value
IF DUA equal with malachite add 50 to mineral value
IF DUA equal with gold add 50 to mineral value
IF DUA equal WITH diamond add 50 to mineral value
STORE TOTAL with 0 value
DO LOOP
IF SATU equal with DUA
ADD total with mineral value
RETURN TOTAL
*/

function salesAmount(satu, dua) {
    // Write your code here
    var mineral = 0
    // MINERAL VALUE
    switch(dua){
      case 'sulfur':
        mineral += 10;
        break;
      case 'silver':
        mineral += 30;
        break;
      case 'malachite':
        mineral += 50;
        break;
      case 'gold':
        mineral += 50;
        break;
      case 'diamond':
        mineral += 100;
        break;
    }
    //TOTAL MINERAL
    var total = 0
    for (i = 0; i < satu.length; i++) {
      for (j = 0; j < satu[i].length; j++) {
        if(satu[i][j] === dua){
          total += mineral
        }
      }
    }
    return total
}

var tambangA = [
  ['gold', 'gold', 'gold', 'diamond', 'diamond', 'sulfur'],
  ['sulfur', 'sulfur', 'sulfur', 'diamond', 'diamond', 'gold']
]
console.log(salesAmount(tambangA, 'gold')); // 200

var tambangB = [
  ['gold', 'gold', 'gold', 'diamond', 'diamond', 'sulfur'],
  ['sulfur', 'sulfur', 'sulfur', 'diamond', 'diamond', 'gold'],
  ['sulfur', 'sulfur', 'sulfur', 'diamond', 'diamond', 'gold'],
]
console.log(salesAmount(tambangB, 'diamond')); // 600

var tambangC = [
  [],
  ['sulfur', 'sulfur', 'silver', 'gold'],
  ['gold', 'diamond']
]
console.log(salesAmount(tambangC, 'sulfur')) // 20
