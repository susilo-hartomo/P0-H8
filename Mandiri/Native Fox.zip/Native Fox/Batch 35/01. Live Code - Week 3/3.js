/* 
===============
Number Triangle
===============
​
Instruction:
Buatlah sebuah proses untuk membuat deret angka yang membentuk segitiga seperti contoh berikut.
​
Contoh 1 (height = 5):
Output:
12345
2345
345
45
5
​
Contoh 2 (height = 3):
Output:
123
23
3
​
Contoh 3 (height = 1):
Output:
1
*/
// Write code here

var input = 4;
display = ''

for (i = 1; i <= input; i++) {
    number = i
    for (j = input; j >= i ; j--) {
        display += number
        number++
    }
    display += '\n'
}
console.log(display);