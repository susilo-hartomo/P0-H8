/*
******
Cari Student
******


Function studentFinder menerima input berupa string berisi nama-nama student sebuah batch, dipisahkan oleh " " atau ",".
Function ini mengeluarkan output berupa nama student dengan jumlah huruf terpendek.
Apabila ada 2 nama student yang terpendek, maka function akan mengeluarkan nama yang berada di posisi sebelah kiri terlebih dahulu!


[RULES]
  - Dilarang menggunakan built-in function .split

*/

function studentFinder(students) {
  var siswa = []
  var tmp = ''
  // CARI SISWA
 for (i = 0; i < students.length; i++) {
   if(students[i] === ' ' || students[i] === ','){
    siswa.push(tmp)
    tmp = ''
    i++
   } else if(i === students.length-1){
     siswa.push(tmp)
   }
   tmp += students[i]
 }
 // CARI TERPENDEK
 for (i = 0; i < siswa.length; i++) {
   for (j = 0;j < siswa.length-1; j++) {
     if (siswa[j].length > siswa[j+1].length) {
       var tmp = siswa[i];
       siswa[j] = siswa[j+1];
       siswa[j+1] = tmp
     }
   }
 }
 return siswa[0]
}

console.log(studentFinder("Hanif Ranev Tio Tirta Igor Yusril Tia Titania")); // Tio
console.log(studentFinder("Yogi Hengky Trina An Hamzah")); // An
console.log(studentFinder("Huday,Kay,Trisna,Kinan,Hazman")); // Kay
