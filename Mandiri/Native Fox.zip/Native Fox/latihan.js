/**
 * ============
 * Tinder match
 * ============
 *
 *
 * Buatlah sebuah fungsi yang akan menerima input array of object sebagai berikut
 * [
 *  { name: 'Andre', gender: 'Men', traits: ['Dewasa', 'Tampan'], expectation: ['Cantik', 'Jujur', 'Kaya']},
 *  { name: 'Marsya', gender: 'Women', traits: ['Cantik', 'Kaya'], expectation: ['Kaya', 'Olahragawan'] },
 *  { name: 'Dimas', gender: 'Men', traits: ['Pintar', 'Kaya'], expectation: ['Cantik', 'Pintar'] },
 *  { name: 'Bella', gender: 'Women', traits: ['Cantik', 'Pintar'], expectation: ['Pintar', 'Jujur'] },
 *  { name: 'Derpina', gender: 'Women', traits: ['Cantik', 'Sederhana', 'Rajin'], expectation: ['Pintar', 'Jujur', 'Baik'] }
 * ]
 *
 * Dan fungsi ini akan mengeluarkan output sebuah object match yang didapatkan oleh setiap orang.
 *
 * {
 *  Andre: {
 *    match: []
 *  },
 *  Marsya: {
 *     match: [ 'Dimas' ]
 *  },
 *  Dimas: {
 *     match: [ 'Marsya', 'Bella', 'Derpina' ]
 *  },
 *  Bella: {
 *     match: [ 'Dimas' ]
 *  },
 *  Derpina: {
 *    match: [ 'Dimas' ]
 *  }
 * }
 *
 * Match didapatkan dengan mencocokan expectation dari setiap orangnya dengan trait orang lain
 * Contoh Marsya match dengan Dimas karena
 * Marsya memiliki Expectation Kaya dan Olahragawan
 * dan Dimas memiliki Traits Pintar dan kaya
 *
 * Karena Dimas memiliki traits Kaya dan Marsya Expectations nya juga kaya mereka adalah pasangan yang match
 *
 * Asumsi
 * =====
 *
 * Setiap orang dianggap match ketika setidaknya memilki satu kesamaan antara expectations dan trait
 *
 */
function tinderMatch(people) {
  var obj = {};
  // CHECK SAME
  for (i = 0; i < people.length; i++) {
    var tmp = { match: [] };
    for (j = 0; j < people.length; j++) {
      if (
        (people[i].gender === "Men" && people[j].gender === "Women") ||
        (people[i].gender === "Women" && people[j].gender === "Men")
      ) {
        for (k = 0; k < people[i].expectation.length; k++) {
          for (l = 0; l < people[j].traits.length; l++) {
            if (people[i].expectation[k] === people[j].traits[l] && people[j].expectation[k] === people[i].traits[l]) {
              tmp.match.push(people[j].name);
            }
          }
          break;
        }
      }
    }
    obj[people[i].name] = tmp;
  }
  return obj;
}
var people = [
  {
    name: "Andre",
    gender: "Men",
    traits: ["Dewasa", "Tampan"],
    expectation: ["Cantik", "Jujur", "Kaya"]
  },
  {
    name: "Marsya",
    gender: "Women",
    traits: ["Cantik", "Kaya"],
    expectation: ["Kaya", "Olahragawan"]
  },
  {
    name: "Dimas",
    gender: "Men",
    traits: ["Pintar", "Kaya"],
    expectation: ["Cantik", "Kaya"]
  },
  {
    name: "Bella",
    gender: "Women",
    traits: ["Cantik", "Pintar"],
    expectation: ["Pintar", "Jujur"]
  },
  {
    name: "Derpina",
    gender: "Women",
    traits: ["Cantik", "Sederhana", "Rajin"],
    expectation: ["Pintar", "Jujur", "Baik"]
  }
];
console.log(tinderMatch(people));
/**
 * {
 *  Andre: {
 *    match: []
 *  },
 *  Marsya: {
 *     match: [ 'Dimas' ]
 *  },
 *  Dimas: {
 *     match: [ 'Marsya', 'Bella', 'Derpina' ]
 *  },
 *  Bella: {
 *     match: [ 'Dimas' ]
 *  },
 *  Derpina: {
 *    match: [ 'Dimas' ]
 *  }
 * }
 */
