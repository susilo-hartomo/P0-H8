/*
  =====
  Top 3
  =====
  Seorang user spotify ingin mengetahui lagu apa saja yang dia putar
  selama seminggu terakhir diurutkan dari paling jarang diputar

  Tugas kamu adalah membuat function sortPlaylist yang menerima inputan
  sebuah array satu dimensi berisi data lagu.

  Output dari function tersebut adalah array 2 dimensi yang menampilkan
  judul lagu terurut dari jumlah pemutaran yang paling sedikit.

  INPUT:
    ['Senorita', 'Senorita', 'I Love You 3000', 'A Whole New World', 'Senorita', 'I Love You 3000', 'Senorita']

  OUTPUT:
    [ 'A Whole New World', 'I Love You 3000', 'Senorita' ]

  RULES:
   - DILARANG MENGGUNAKAN BUILT IN FUNCTION APAPUN KECUALI .push()
*/

function sortPlaylist(playlist) {
  // your code here

}

console.log(sortPlaylist(['Senorita', 'Senorita', 'I Love You 3000', 'A Whole New World', 'Senorita', 'I Love You 3000', 'Senorita']));
// [ 'A Whole New World', 'I Love You 3000', 'Senorita' ]

console.log(sortPlaylist('Donna Donna', 'Top of The World', 'Donna Donna', 'Top of The World', 'Top of The World', 'Location Unknown'));
// [ 'Location Unknown', 'Donna Donna', 'Top of The World' ]

console.log(sortPlaylist([])); // []
