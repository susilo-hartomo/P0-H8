function MakanKantin(listHarga, history) {
    var display = []
    var tmp = []
    var temp = ''
    // SPLIT
    for (i = 0; i < history.length; i++) {
      if(history[i] === '-' || history[i] === ','){
        tmp.push(temp)
        temp = ''
      } else if(history[i] === '.'){
        tmp.push(temp)
        display.push(tmp)
        tmp = []
        temp = ''
      } else {
        temp += history[i]
      }
    }
    tmp.push(temp)
    display.push(tmp)
    // DISPLAY
    var obj = {}
    var tabungan = 0
    
    for (i = 0; i < display.length; i++) {
      var total = 10000
      for (j = 1; j < display[i].length; j++) {
        for (k = 0; k < listHarga.length; k++) {
          if(display[i][j] === listHarga[k].nama){
            total -= listHarga[k].harga
          }
        }
      }
      obj[display[i][0]] = total
      tabungan += total
    }
    obj.TotalTabungan = tabungan

    return obj
  }
  
  var hargaMakanan = [
    { nama: "ayam", harga: 5000 },
    { nama: "nasi", harga: 2000 },
    { nama: "cola", harga: 1000 },
    { nama: "chiki", harga: 1500 },
    { nama: "hotdog", harga: 3000 },
    { nama: "aqua", harga: 2000 }
  ]
  var historyPembelian = `Senin-ayam,nasi,cola.Selasa-chiki,hotdog.Rabu-ayam,chiki.Kamis-hotdog.Jumat-chiki,cola,nasi`
  
  console.log(MakanKantin(hargaMakanan, historyPembelian))
  
  /*
  {
    Senin: 2000,
    Selasa: 5500,
    Rabu: 3500,
    Kamis: 7000,
    Jumat: 5500,
    TotalTabungan: 23500
  }
  */