function push(item) {
    let add = 'Phase 3';
    item[item.length] = add;
    return item;
}
console.log(push(['Phase 0', 'Phase 1', 'Phase 2']));

// let nama = ['F', 'a', 's', 'e'];
// let temp = ['I', 'm', 'm', 'e', 'r', 's', 'i', 'v', 'e'];
// for (let i = 0; i < temp.length; i++) {
//     nama[nama.length] = temp[i];
// }
// console.log(nama);