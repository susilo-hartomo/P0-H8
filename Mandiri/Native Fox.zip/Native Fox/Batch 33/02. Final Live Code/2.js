/*
  HEROES
  Heroes adalah sebuah fungsi untuk menentukkan karakter apa saja yang disukai
  orang sehingga yang duplikat tidak perlu dicatat.
  Fungsi akan menerima parameter berupa string

  EXAMPLE
  INPUT: "saitama&&naruto&&nobita&&nobita&&saitama&&sasuke"
  OUTPUT: [saitama, naruto, nobita, sasuke]

  RULES:
  1. Tidak boleh menggunakan built in function selain .push(), .unshift()
*/
function Heroes(hero) {
  var display = []
  var arr = []
  var tmp = ''
  // CARI HEROES
  for (i = 0; i < hero.length; i++) {
    if(hero[i] !== '&'){
      tmp += hero[i]
    } else if(hero[i] === '&'){
      arr.push(tmp)
      tmp = ''
      i++
    } 
    if(i === hero.length-1){
      arr.push(tmp)
      tmp = ''
    }
  }
  // CEK HEROES
  for (i = 0; i < arr.length; i++) {
    var sama = false
    for (j = 0; j < display.length; j++) {
      if(arr[i] === display[j]){
        sama = true
      }
    }
    if(sama === false){
      display.push(arr[i])
    }
  }
  // OUTPUT
  if(hero == false){
    return `There's no heroes`
  } else {
    return display
  }
}

// TEST CASE
console.log(Heroes("saitama&&naruto&&nobita&&nobita&&saitama&&sasuke"));
// [ 'saitama', 'naruto', 'nobita', 'sasuke' ]
console.log(
  Heroes("doraemon&&sakura&&inuyasha&&saitama&&shoji&&ikan indosiar")
);
// [ 'doraemon', 'sakura', 'inuyasha', 'saitama', 'shoji', 'ikan indosiar' ]
console.log(Heroes(""));
// There's no heroes
