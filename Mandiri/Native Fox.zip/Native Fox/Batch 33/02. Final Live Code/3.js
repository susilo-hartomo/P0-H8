/*
  /////////////////////
  2ND WINNER GUILD WARS
  /////////////////////

  Function Guild Wars akan menentukkan juara ke-2 dalam bentuk string, dari peringkat 1 ke 4.
  Jumlah peserta selalu array dengan length 4.  

  EXAMPLE
  INPUT: ['OOOO', 'ooOO', 'o', 'OOo']
  INFO:
  - O dihitung 2 
  - o dihitung 1
  GUIDE: 
  - Awal Sisi Kiri: (Tim 1 vs Tim 2) dan Sisi Kanan: (Tim 3 vs Tim 4)
  - Pemenang dari Sisi Kiri vs pemenang dari Sisi Kanan menghasilkan juara 1 dan 2
  - Yang kalah dari Sisi Kiri vs yang kalah dari Sisi Kanan menghasilkan juara 3 dan 4
  PROCESS:
  - Sisi Kiri => OOOO vs ooOO => OOOO (win), ooOO (lose)
  - Sisi Kanan => o vs OOo => o (lose), OOo (win)
  - Winner vs Winner => OOOO vs OOo => OOOO (1), OOo (2)
  - Loser vs Loser => ooOO vs o => ooOO(3), o (4)
  win 
  - Urutan pemenang [OOOO, OOo, ooOO, o]
  OUTPUT:
  Juara Ke-2 adalah tim OOo

  RULES:
  1. Jumlah yang bertanding selalu 4 tim
  2. Asumsi total kekuatan di setiap tim tidak ada yang sama
*/
function guildWars(guilds) {
  /*
  // OPSI OBJECT
  let count = 0;
  let temp = {};
  for (let i = 0; i < guilds.length; i++) {
    temp[guilds[i]] = 0;
    for (let j = 0; j < guilds.length; j++) {
      switch (guilds[i][j]) {
        case "O":
          temp[guilds[i]] += 2;
          break;

        case "o":
          temp[guilds[i]]++;
          break;

        default:
          break;
      }
    }
  }
  let arr = [];
  for (const key in temp) {
    arr.push(temp[key]);
  }

  arr.sort();
  for (const key in temp) {
    if (arr[1] == temp[key]) {
      return "Juara ke-2 adalah tim " + key;
    }
  }
  */

  // OPSI NORMAL
  var value = []
  var gugur = []
   
  // CARI VALUE PLAYERS
  var tmp = 0
  for (i = 0; i < guilds.length; i++) {
    for (j = 0; j < guilds[i].length; j++) {
      if(guilds[i][j] === 'O'){
        tmp += 2
      } else if(guilds[i][j] === 'o'){
        tmp += 1
      }
    }
    value.push([tmp,guilds[i]])
    tmp = 0
  }
  // CARI KIRI
  var kiri = []
  if(value[0][0] > value[1][0]){
    kiri.push(value[0])
    gugur.push(value[1])
  } else {
    kiri.push(value[1])
    gugur.push(value[0])
  }
  // CARI KANAN
  var kanan = []
  if(value[2][0] > value[3][0]){
    kanan.push(value[2])
    gugur.push(value[3])
  } else {
    kanan.push(value[3])
    gugur.push(value[2])
  }
  // CARI WINNER
  var winner = []
  if(kiri[0][0] > kanan[0][0]){
    winner.push(kiri[0][1],kanan[0][1])
  } else {
    winner.push(kanan[0][1],kiri[0][1])
  }
  // CARI KETIGA
  if(gugur[0][0] > gugur [1][0]){
    winner.push(gugur[0][1],gugur[1][1])
  } else {
    winner.push(gugur[1][1],gugur[0][1])
  }
  // OUTPUT
  return `Juara ke-2 adalah tim ${winner[1]}`
}

console.log(guildWars(["OOOO", "ooOO", "o", "OOo"]));
// Juara ke-2 adalah tim OOo
console.log(guildWars(["OO", "OOO", "ooOOO", "OOOo"]));
// Juara ke-2 adalah tim OOO
console.log(guildWars(["ooo", "oooo", "oo", "o"]));
// Juara ke-2 adalah tim oo
