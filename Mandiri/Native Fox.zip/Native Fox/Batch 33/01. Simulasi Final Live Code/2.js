/*
========
MARATHON
========
[INSTRUCTION]
Kamu mengikuti lomba marathon, dengan rute lintasan tertentu dan stamina tertentu;
[EXAMPLE]
input lintasan: 'XXXXXXOOO-XXOOXXXXXOO-XXXXO'
['XXXX', 'XX', 'OO', O-XXOOXXXXXOO-XXXXO']
[-1,   3]
'X' adalah jalan datar yang akan mengkonsumsi 1 stamina dengan maskimal repetisi 'X' 4 kali  ('XXXX')
'O' adalah jalan menanjak yang akan mengkonsumsi 1 stamina dengan maksimal repetisi 'O' 2 kali ('OO')
'-' adalah spot minum meningkatkan 2 stamina
partisi track:   XXXX XX OO O -  X   X O   O X   X  X  X XOO-XXXXO
stamina      : 5    4  3  2 1 3      2     1           0 (ENERGI HABIS, TIDAK BISA MELANJUTKAN)
jarak lari   :   1234 56 78 9 10 11,12 13,14 15,16,17,18
input stamina: 5
output: Selamat anda telah menempuh jarak 18
[RULES]
- Dilarang menggunakan .split, .join, .map, .sort, .filter, .indexOf, .includes
- WAJIB menggunakan pseudocode
*/

function marathon(track, stamina) {
  var life = stamina
  var x = 0
  var o = 0
  var jarak = 0

  for (i = 0; i < track.length; i++) {
    jarak += 1
    if(track[i] === 'X'){
      x++
    } else if(track[i] === 'O'){
      o++
    } else {
      life += 2
    }
    if(track[i] !== track[i+1] && track[i] !== '-'){
      life --
      x = 0
      o = 0
    }
    if(x === 4 || o === 2){
      life --
      x = 0
      o = 0
    }
    if(life === 0){
      break
    }
  }
  // OUTPUT
  if(jarak === track.length){
    return `Selamat anda telah menempuh garis finish`
  } else {
    return `Selamat anda telah menempuh jarak ${jarak} KM`
  }
}

console.log(marathon("XXXXXXOOO-XXOOXXXXXOO-XXXXO", 5)); // Selamat anda telah menempuh jarak 18 km
console.log(marathon("XXXXXXOOOXXOOXXXXXOOXXXXO", 5)); // Selamat anda telah menempuh jarak 11 km
console.log(marathon("XXXXXXXX", 3)); // Selamat anda telah menempuh garis finish
